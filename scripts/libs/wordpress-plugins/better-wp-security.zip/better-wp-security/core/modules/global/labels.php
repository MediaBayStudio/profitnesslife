<?php

return [
	'title' => __( 'Global', 'better-wp-security' ),
];
