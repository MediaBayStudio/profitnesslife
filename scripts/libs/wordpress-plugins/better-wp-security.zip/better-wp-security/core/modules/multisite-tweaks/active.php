<?php

require_once( 'class-itsec-multisite-tweaks.php' );
$itsec_multisite_tweaks = new ITSEC_Multisite_Tweaks();
$itsec_multisite_tweaks->run();
