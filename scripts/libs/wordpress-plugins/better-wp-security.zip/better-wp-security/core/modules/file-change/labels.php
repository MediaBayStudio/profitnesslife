<?php

return [
	'title' => __( 'File Change', 'better-wp-security' ),
];
