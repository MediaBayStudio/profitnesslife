<?php

return [
	'title' => __( '404 Detection', 'better-wp-security' ),
];
