<?php

return [
	'title' => __( 'Change Database Prefix', 'better-wp-security' ),
];
