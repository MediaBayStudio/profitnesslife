<?php
/**
 * Loads the Image SEO class file.
 *
 * @since   3.4.0
 * @package All-in-One-SEO-Pack
 */

if ( AIOSEOPPRO ) {
	require_once( AIOSEOP_PLUGIN_DIR . 'pro/class-aioseop-image-seo.php' );
}
