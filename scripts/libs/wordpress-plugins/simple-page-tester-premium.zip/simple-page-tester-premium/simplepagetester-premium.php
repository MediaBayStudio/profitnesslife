<?php
/*
* Plugin Name: Simple Page Tester Premium
*
* Description: Premium add-on features for the acclaimed Simple Page Tester plugin
*
* Author: Simple Page Tester
* Author URI: http://www.simplepagetester.com
* Plugin URI: http://simplepagetester.com
* Version: 1.4.2
*/

/*******************************************************************************
** sptRegisterPremiumMetaBoxes
** Register the various meta boxes used throughout the admin
** @since 1.0
*******************************************************************************/
function sptRegisterPremiumMetaBoxes() {

	// Register required premium meta boxes on the SPT edit screen
	add_meta_box(
		'spt-side-details-meta',
		'Split Test Analysis',
		'sptSideDetailsMetaBox',
		'spt',
		'side',
		'low'
	);

	add_meta_box(
		'spt-conversion-code-meta',
		'Conversion Code',
		'sptShortcodeMetaBox',
		'spt',
		'side',
		'low'
	);

	// Remove the premium upsell meta box
	remove_meta_box( 'spt-side-premium-upsell-meta', 'spt', 'side' );

	// 1.1 (jkohlbach): Add meta boxes to CPTs that are enabled
	$sptPremiumSettings = get_option('sptPremiumSettings');

	if (!empty($sptPremiumSettings['enabledPostTypes'])) {
		foreach (array_keys($sptPremiumSettings['enabledPostTypes']) as $postType) {
			add_meta_box(
				'spt-page-sidebar-meta',
				'Split Test',
				'sptPageSidebarBoxMeta',
				$postType,
				'side',
				'low'
			);
		}
	}

}

/*******************************************************************************
** sptAddPremiumOptions
** Add split test specific options
** @since 1.2
*******************************************************************************/
function sptAddPremiumOptions() {
	wp_nonce_field( plugin_basename(__FILE__), 'spt_noncename' );
	global $post;

	/* Make sure we only do this for regular saves and we have permission */
	if ((defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) ||
		!current_user_can( 'edit_page', $post->ID ) ) {
		return $post->ID;
	}

	// Get the split test data
	$sptData = unserialize(get_post_meta($post->ID, 'sptData', true));

	if (isset($sptData['splitTestType']) && $sptData['splitTestType'] == 'shortcode') {
		echo '<p><label style="font-weight: bold;">Split Test Type:</label> Shortcode
		<input type="hidden" name="sptData[splitTestType]" value="shortcode" /></p>';
	} else {
		echo '<p><label style="font-weight: bold;">Split Test Type:</label> Page
		<input type="hidden" name="sptData[splitTestType]" value="page" /></p>';
	}

}

/*******************************************************************************
** sptSideDetailsMetaBox
** Present the details for the split test
** @since 1.0
*******************************************************************************/
function sptSideDetailsMetaBox() {
	wp_nonce_field( plugin_basename(__FILE__), 'spt_noncename' );
	global $post;

	/* Make sure we only do this for regular saves and we have permission */
	if ((defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) ||
		!current_user_can( 'edit_page', $post->ID ) ) {
		return $post->ID;
	}

	// Get the split test data
	$sptData = unserialize(get_post_meta($post->ID, 'sptData', true));
	$statsData = sptGetStatsData( $post->ID );
	$masterViews = count( $statsData[ $sptData[ 'master_id' ] ][ 'views' ] );
	$slaveViews = count( $statsData[ $sptData[ 'slave_id' ] ][ 'views' ] );

	// Populate the variation data
	$master = array(
		'visits' => $masterViews,
		'conversions' => ( isset( $sptData[ $sptData[ 'master_id' ] . '_conversions' ] ) ? count( $sptData[ $sptData[ 'master_id' ] . '_conversions' ] ) : 0 )
	);

	$variation = array(
		'visits' => $slaveViews,
		'conversions' => ( isset( $sptData[ $sptData[ 'slave_id' ] . '_conversions' ] ) ? count( $sptData[ $sptData[ 'slave_id' ] . '_conversions' ] ) : 0)
	);

	// Test if we should do the math yet
	if ($master['visits'] == 0 || $master['conversions'] == 0 ||
		$variation['visits'] == 0 || $variation['conversions'] == 0) {
		echo '<div style="font-size: 120%;">Please continue running your test so we can collect
			more data.<br /><br /></div>';
	} else {
		// Start doing our math
		require_once('spt-math.php');
		$sptMath = new SPT_Math();

		if ($sptMath->conversion_rate($master) < $sptMath->conversion_rate($variation)) {
			$confidence_percent = $sptMath->cumulative_normal_distribution(
				$sptMath->zscore($master, $variation)
			);

			$change_percent = $sptMath->change_percent($master, $variation);

			$whoIsWinning = 'Variation';
			$whoIsLosing = 'Master';
		} else {
			$confidence_percent = $sptMath->cumulative_normal_distribution(
				$sptMath->zscore($variation, $master)
			);

			$change_percent = $sptMath->change_percent($variation, $master);

			$whoIsWinning = 'Master';
			$whoIsLosing = 'Variation';
		}

		echo '<div style="font-size: 120%;">There is an <span class="sptBiggerText">' .
		number_format($confidence_percent * 100, 0) . '% chance</span> that the ' .
		$whoIsWinning . ' is better than the ' . $whoIsLosing .
		' by <span class="sptBiggerText">' . number_format($change_percent * 100, 0) .
		'%</span>.<br /><br />';

		if ($confidence_percent * 100 > 95) {
			echo 'Congratulations, this a <span class="sptBiggerText">statistically significant
			result</span>.<br /><br />Feel free to continue running your test as more data means
			more certainty.<br /><br />';
		} else {
			echo 'However, this is <span class="sptBiggerText">not a statistically significant
			result</span>.<br /><br />Please continue running your test so we can collect
			more data.<br /><br />';
		}

		echo '</div>';
	}

}

/*******************************************************************************
** sptShortcodeMetaBox
** Present the conversion code meta box
** @since 1.0
*******************************************************************************/
function sptShortcodeMetaBox() {
	wp_nonce_field( plugin_basename(__FILE__), 'spt_noncename' );
	global $post;

	/* Make sure we only do this for regular saves and we have permission */
	if ((defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) ||
		!current_user_can( 'edit_page', $post->ID ) ) {
		return $post->ID;
	}

	echo '<p>Paste this shortcode in the page your users see after they convert.<br />
	<em>eg. Order Received page, Newsletter Subscribe Success page, etc.</em></p>';

	echo '<p><input style="background: #EEE; width: 100%;" name="" id="sptConversionShortcodeText" type="text" value="[spt_conversion id=' . $post->ID . ']" readonly="readonly" /></p>';

	echo '<p><strong>Advanced Users:</strong></p>';

	echo '<p><a id="sptShowTemplateCode" style="cursor: pointer;">Show Template Code +</a></p>
	<div id="sptTemplateCode" style="display: none;">
	<textarea style="background: #EEE;width: 100%;" readonly="readonly">sptRecordConversion(array(\'id\' => \'' . $post->ID . '\'));</textarea>
	</div>';

	echo '<p><a id="sptShowJSCode" style="cursor: pointer;">Show Javascript Code +</a></p>
	<div id="sptJSCode" style="display: none;">
	<textarea style="background: #EEE;width: 100%;" readonly="readonly">sptRecordConversion(' . $post->ID . ');</textarea>
	</div>';

	echo '<script type="text/javascript">
	jQuery("#sptConversionShortcodeText, #sptTemplateCode textarea, #sptJSCode textarea").click(function() {
		jQuery(this).select();

		jQuery(this).mouseup(function() {
	        // Prevent further mouseup intervention
	        jQuery(this).unbind("mouseup");
	        return false;
	    });
	});

	jQuery("#sptShowTemplateCode").click(function() {
		jQuery("#sptTemplateCode").slideToggle();

		if (jQuery("#sptShowTemplateCode").text() == "Show Template Code +") {
			jQuery("#sptShowTemplateCode").text("Show Template Code -");
		} else {
			jQuery("#sptShowTemplateCode").text("Show Template Code +");
		}
	});

	jQuery("#sptShowJSCode").click(function() {
		jQuery("#sptJSCode").slideToggle();

		if (jQuery("#sptShowJSCode").text() == "Show Javascript Code +") {
			jQuery("#sptShowJSCode").text("Show Javascript Code -");
		} else {
			jQuery("#sptShowJSCode").text("Show Javascript Code +");
		}
	});
	</script>';
}

/*******************************************************************************
** sptRecordConversion
** Record a conversion for the given split test ID
** @since 1.0
*******************************************************************************/
function sptRecordConversion($atts) {
	global $sptSession;

	extract($atts);

	// Get the SPT ID from the shortcode, bail if not found
	if (!isset($id) || empty($id))
		return;

	// Check for the last known page ID, if we don't have it bail because we don't know
	// which page to record the conversion against
	$testLastPageID = $sptSession->getData('spt_' . $id . '_last_pageid');
	if (!isset($testLastPageID) || empty($testLastPageID))
		return;

	/* 1.2.1: Handle multiple running tests by checking for last test viewed. If
	** the last test isn't set, don't record a conversion. Likewise, if the last
	** test wasn't this one, don't record a conversion. */
	$lastTestViewed = $sptSession->getData('spt_last_test_viewed');
	if (!isset($lastTestViewed) ||
		empty($lastTestViewed) ||
		$lastTestViewed != $id)
		return;

	// Get the split test data
	$sptData = unserialize(get_post_meta($id, 'sptData', true));

	// Handle shortcode test type conversions
	if ($testLastPageID == 'master') {
		$sptSession->setData('spt_' . $id . '_last_pageid', $sptData['master_id']);
	} else if ($testLastPageID == 'variation') {
		$sptSession->setData('spt_' . $id . '_last_pageid', $sptData['slave_id']);
	}

	// Record a conversion against that last known page
	$lastKnownPage = $sptSession->getData('spt_' . $id . '_last_pageid');
	$sptData[$lastKnownPage . '_conversions'][] = array(
		'timestamp' => current_time('timestamp'),
		'ip' => getenv(REMOTE_ADDR)
	);

	// 1.2.1: Clear the session data so this can't be recorded twice
	$sptSession->unsetData('spt_' . $id . '_last_pageid');

	// Update the split test data
	update_post_meta($id, 'sptData', serialize($sptData));
}

/*******************************************************************************
** sptAjaxRecordConversion
** Ajax handler for the record recording (supports the javascript tracking)
** @since 1.2
*******************************************************************************/
function sptAjaxRecordConversion() {
	$sptID = sptFilterData($_POST['sptID']);

	// Bail if test ID not provided
	if (!isset($sptID) || empty($sptID) || !is_numeric($sptID))
		return;

	global $sptSession;

	if (!$sptSession)
		$sptSession = new SPTSessionHandler();

	sptRecordConversion(array('id' => (int)$sptID));

	die();
}

/*******************************************************************************
** sptRecordPageAfterRedirect
** Record the last known page ID in the session so we can attribute the
** conversion to the right page
** @since 1.0
*******************************************************************************/
function sptRecordPageAfterRedirect($sptID) {
	global $sptSession;

	global $post;

	// Record the last known page ID so we know what page to attribute conversions to
	$sptSession->setData('spt_' . $sptID . '_last_pageid', $post->ID);

	sptRecordLastTestViewed($sptID);
}

/*******************************************************************************
** sptRecordLastTestViewed
** Record the most recently viewed test in the session variable.
** @since 1.2.1
*******************************************************************************/
function sptRecordLastTestViewed($sptID) {
	global $sptSession;

	// Record last test viewed
	$sptSession->setData('spt_last_test_viewed', $sptID);
}

/*******************************************************************************
** sptAddConversionsTotal
** Add conversion details to the split test details on the edit page
** @since 1.0
*******************************************************************************/
function sptAddConversionsTotal($sptID, $pageID) {
	$sptData = unserialize(get_post_meta($sptID, 'sptData', true));
	$statsData = sptGetStatsData( $sptID );

	$conversion_percent = 0.00;

	if (!isset( $statsData ) ||
		!isset( $sptData[ $pageID . '_conversions' ] ) ||
		count( $sptData[ $pageID . '_conversions' ] ) == 0 ||
		count( $statsData[ $pageID ][ 'views' ] ) == 0 ) {
		$conversion_percent = 0.00;
	} else {
		$conversion_percent = isset( $sptData[ $pageID . '_conversions' ] ) ? ( count( $sptData[ $pageID . '_conversions' ] ) / count( $statsData[ $pageID ][ 'views' ] ) * 100) : 0;
	}

	echo '<tr>
			<th scope="row" colspan="1">Total Conversions:</th>
			<td colspan="2">' . ( isset( $sptData[ $pageID . '_conversions' ] ) ? count( $sptData[ $pageID . '_conversions' ] ) : 0 ) . '</td>
		</tr>
		<tr>
			<th scope="row" colspan="1">Conversion %:</th>
			<td colspan="2">' . number_format( $conversion_percent, 2 ) . '%</td>
		</tr>';

}

/*******************************************************************************
** sptAddConversionsToChart
** Add conversion details to the split test chart
** @since 1.0
*******************************************************************************/
function sptAddConversionsToChart($dataArray, $splitTestID) {
	// Get the test data
	$sptData = unserialize(get_post_meta($splitTestID, 'sptData', true));
	$newDataArray = array();

	// Go through all the dates and build the new data array with conversions included
	foreach ($dataArray as $key => $data) {
		$conversionsForDate = 0;

		// Get date
		$date = $data[0];

		$unixStartOfDate = mktime(00, 00, 00, date("m", strtotime($date)), date("d", strtotime($date)), date("Y", strtotime($date)));
		$unixEndOfDate = mktime(23, 59, 59, date("m", strtotime($date)), date("d", strtotime($date)), date("Y", strtotime($date)));

		// Get this day's conversions on this page
		$masterConversionsForDate = count(sptConversionsForPeriod($splitTestID, $sptData['master_id'], $unixStartOfDate, $unixEndOfDate));
		$variationConversionsForDate = count(sptConversionsForPeriod($splitTestID, $sptData['slave_id'], $unixStartOfDate, $unixEndOfDate));

		// Add this day's conversions to the array
		$newDataArray[] = array($date, $data[1], (!empty($masterConversionsForDate) ? $masterConversionsForDate : 0), $data[2], (!empty($variationConversionsForDate) ? $variationConversionsForDate : 0));
	}

	return $newDataArray;
}

/*******************************************************************************
** sptConversionsForPeriod
** Return the conversions for a given period for the given page on the given
** split test
** @since 1.0
*******************************************************************************/
function sptConversionsForPeriod($splitTestID, $pageID, $startDate, $endDate) {

	$sptData = unserialize(get_post_meta($splitTestID, 'sptData', true));

	if (!$sptData)
		return;

	$conversionsForPeriod = array();

	if (!empty($sptData) && !empty($sptData[$pageID . '_conversions'])) {
		foreach ($sptData[$pageID . '_conversions'] as $conversion) {
			if ($conversion['timestamp'] > $startDate &&
				$conversion['timestamp'] <= $endDate) {

				// Conversion was within date parameters
				$conversionsForPeriod[] = $conversion;
			}
		}
	}

	usort($conversionsForPeriod, 'sptStatsSortFunction');
	return $conversionsForPeriod;
}

/*******************************************************************************
** sptLicenseSettingsPage
** Setup the license key entry page
** @since 1.0
*******************************************************************************/
function sptLicenseSettingsPage() {
	if (!current_user_can('manage_options'))  {
		wp_die( __('You do not have suffifient permissions to access this page.') );
	}

	$sptLicenseData = get_option('sptLicenseData');
	update_option('sptLicenseData',['email' => 'valid@mail.com', 'key' =>'raz-0-r']);
	echo '<div class="wrap">
	<h2>Simple Page Tester Premium License Details</h2>

	<form method="post" action="options.php">';

	settings_fields('sptLicenseData');
    do_settings_sections('sptLicenseData');

    echo '<table class="form-table">
		<tr valign="top">
			<th scope="row">Enter your license email:</th>
			<td><input type="text" name="sptLicenseData[email]" value="' . $sptLicenseData['email'] . '" /></td>
			<td class="description">Usually this is the email you used when you purchased.</td>
		</tr>

		<tr valign="top">
			<th scope="row">Enter your license key:</th>
			<td><input type="text" name="sptLicenseData[key]" value="' . $sptLicenseData['key'] . '" /></td>
			<td class="description">Your license key.</td>
		</tr>
	</table>';

	submit_button();

	echo '</form>
	<hr />
	<h3>Join the SPT community!</h3>
	<ul id="thirstyCommunityLinks">
		<li><a href="http://simplepagetester.com">Visit Our Website</a></li>
		<li><a href="http://simplepagetester.com/affiliate-sign-up/">Join Our Affiliate Program</a></li>
		<li><a href="http://facebook.com/SimplePageTester" style="margin-right: 10px;">Like us on Facebook</a><iframe src="//www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2FSimplePageTester&amp;send=false&amp;layout=button_count&amp;width=450&amp;show_faces=false&amp;font=arial&amp;colorscheme=light&amp;action=like&amp;height=21" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:450px; height:21px; vertical-align: bottom;" allowTransparency="true"></iframe></li>
		<li><a href="https://twitter.com/splittestplugin" style="margin-right: 10px;">Follow us on Twitter</a> <a href="https://twitter.com/splittestplugin" class="twitter-follow-button" data-show-count="true" style="vertical-align: bottom;">Follow @splittestplugin</a><script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?"http":"https";if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document, "script", "twitter-wjs");</script></li>
	</ul>
	</div><!-- /.wrap -->';
}

/*******************************************************************************
** sptLicenseSettingsPage
** Register the settings for the license details
** @since 1.0
*******************************************************************************/
function sptRegisterLicenseSettings() {
	register_setting('sptLicenseData', 'sptLicenseData');
}

/*******************************************************************************
** sptSetupLicenseDetailsPage
** Add SPT license page to plugins menu
** @since 1.0
*******************************************************************************/
function sptSetupLicenseDetailsPage() {
	add_submenu_page(
		'edit.php?post_type=spt',
		'License Settings',
		'License Settings',
		'manage_options',
		'sptLicenseData',
		'sptLicenseSettingsPage'
	);
}

/*******************************************************************************
** sptPremiumSettingsPage
** Setup the Premium Settings page
** @since 1.1
*******************************************************************************/
function sptPremiumSettingsPage() {
	if (!current_user_can('manage_options'))  {
		wp_die( __('You do not have suffifient permissions to access this page.') );
	}

	$sptPremiumSettings = get_option('sptPremiumSettings');

	$sptPremiumSettings['cookiesForTracking'] = isset($sptPremiumSettings['cookiesForTracking']) && $sptPremiumSettings['cookiesForTracking'] == 'on' ? ' checked="checked"' : '';

	echo '<div class="wrap">
	<h2>Simple Page Tester Premium Settings</h2>

	<form method="post" action="options.php">';

	settings_fields('sptPremiumSettings');
    do_settings_sections('sptPremiumSettings');

    echo '<table class="form-table">
		<tr valign="top">
			<th scope="row">Enable Split Testing On Custom Post Types:</th>
			<td width="20%">';

	$allPostTypes = get_post_types(array(
		'public' => true
	));

	// Unset the SPT post type if it's there
	unset($allPostTypes['spt']);

	if (empty($sptPremiumSettings['enabledPostTypes'])) {
		// If there are no enabled post types in the settings, enabled posts and pages by default
		$sptPremiumSettings['enabledPostTypes']['post'] = 'on';
		$sptPremiumSettings['enabledPostTypes']['page'] = 'on';
		update_option('sptPremiumSettings', $sptPremiumSettings);
		$sptPremiumSettings = get_option('sptPremiumSettings');
	}

	/* If post not enabled, enable it, we never want to show this disabled (in reality it never
	will because it's set in the core plugin separately) */
	if (!isset($sptPremiumSettings['enabledPostTypes']['post']) || empty($sptPremiumSettings['enabledPostTypes']['post']))
		$sptPremiumSettings['enabledPostTypes']['post'] = 'on';

	// Do the same for page post type as well, if not enabled, enable it
	if (!isset($sptPremiumSettings['enabledPostTypes']['page']) || empty($sptPremiumSettings['enabledPostTypes']['page']))
		$sptPremiumSettings['enabledPostTypes']['page'] = 'on';

	// Display post types selectors
	foreach ($allPostTypes as $postType) {
		echo '<input type="checkbox" name="sptPremiumSettings[enabledPostTypes][' . $postType . ']" id="sptPremiumSettings' . $postType . '" ' .
			($sptPremiumSettings['enabledPostTypes'][$postType] == 'on' ? ' checked="checked"' : '') . ' />
			<label for="sptPremiumSettings' . $postType . '">' . $postType . '</label><br />';
	}

	echo '</td>
			<td class="description">Enable split testing functionality on custom post types used on your website. Split testing is enabled on Pages and Posts by default.</td>
		</tr>';

	/* TODO: Add feature for using cookies to track instead of session data */
	/*echo '<tr valign="top">
			<th scope="row"><label for="cookiesForTracking">Use cookies for session tracking?</label></th>
			<td><input type="checkbox" id="cookiesForTracking" name="sptPremiumSettings[cookiesForTracking]" ' . $sptPremiumSettings['cookiesForTracking'] . ' /></td>
			<td class="description">Rather than using session data which gets destroyed at the end of the browsing session, use persistent cookies for tracking user behaviour.</td>
		</tr>';*/

	echo '</table>';

	submit_button();

	echo '</form>
	<hr />
	<h3>Join the SPT community!</h3>
	<ul id="thirstyCommunityLinks">
		<li><a href="http://simplepagetester.com">Visit Our Website</a></li>
		<li><a href="http://simplepagetester.com/affiliate-sign-up/">Join Our Affiliate Program</a></li>
		<li><a href="http://facebook.com/SimplePageTester" style="margin-right: 10px;">Like us on Facebook</a><iframe src="//www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2FSimplePageTester&amp;send=false&amp;layout=button_count&amp;width=450&amp;show_faces=false&amp;font=arial&amp;colorscheme=light&amp;action=like&amp;height=21" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:450px; height:21px; vertical-align: bottom;" allowTransparency="true"></iframe></li>
		<li><a href="https://twitter.com/splittestplugin" style="margin-right: 10px;">Follow us on Twitter</a> <a href="https://twitter.com/splittestplugin" class="twitter-follow-button" data-show-count="true" style="vertical-align: bottom;">Follow @splittestplugin</a><script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?"http":"https";if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document, "script", "twitter-wjs");</script></li>
	</ul>
	</div><!-- /.wrap -->';
}

/*******************************************************************************
** sptRegisterPremiumSettings
** Register the settings for the premium features
** @since 1.1
*******************************************************************************/
function sptRegisterPremiumSettings() {
	register_setting('sptPremiumSettings', 'sptPremiumSettings');
}

/*******************************************************************************
** sptSetupPremiumSettingsPage
** Add SPT premium settings page to settings menu
** @since 1.1
*******************************************************************************/
function sptSetupPremiumSettingsPage() {
	add_submenu_page(
		'edit.php?post_type=spt',
		'Premium Settings',
		'Premium Settings',
		'manage_options',
		'sptPremiumSettings',
		'sptPremiumSettingsPage'
	);
}

/*******************************************************************************
** sptSaveConversionsDuringSave
** Initialise the premium version
** @since 1.0.1
*******************************************************************************/
function sptSaveConversionsDuringSave($sptData, $sptDataOrig) {
	$sptData[$sptDataOrig['master_id'] . '_conversions'] = $sptDataOrig[$sptDataOrig['master_id'] . '_conversions'];
	$sptData[$sptDataOrig['slave_id'] . '_conversions'] = $sptDataOrig[$sptDataOrig['slave_id'] . '_conversions'];

	return $sptData;
}

/*******************************************************************************
** sptAddPostTypeButtonsToNewPageTestPage
** Add all the enabled post types buttons to the add new page test page
** @since 1.2
*******************************************************************************/
function sptAddPostTypeButtonsToNewPageTestPage() {
	$sptPremiumSettings = get_option('sptPremiumSettings');
	if ( !empty( $sptPremiumSettings['enabledPostTypes'] ) ) {
		foreach (array_keys($sptPremiumSettings['enabledPostTypes']) as $postType) {
			if ($postType != 'post' && $postType != 'page') {
				$postTypeObj = get_post_type_object($postType);

				echo '<a href="' . admin_url('edit.php?post_type=' . $postType) .
				'" class="button-primary">Goto ' . $postTypeObj->labels->name .
				' Listing &rarr;</a>&nbsp;';

			}
		}
	}
}

/*******************************************************************************
** sptResetConversionStats
** Reset conversion stats when prompted on the backend
** @since 1.2
*******************************************************************************/
function sptResetConversionStats($sptData) {
	// Reset conversion stats
	$sptData[$sptData['master_id'] . '_conversions'] = array();
	$sptData[$sptData['slave_id'] . '_conversions'] = array();

	return $sptData;
}

/*******************************************************************************
** sptAddConversionStatsToList
** Add conversion stats to the stats list screen column
** @since 1.2
*******************************************************************************/
function sptAddConversionStatsToList($html, $sptData, $sptID) {
	require_once('spt-math.php');
	$sptMath = new SPT_Math();

	$statsData = sptGetStatsData( $sptID );
	$masterViews = count( $statsData[ $sptData[ 'master_id' ] ][ 'views' ] );
	$slaveViews = count( $statsData[ $sptData[ 'slave_id' ] ][ 'views' ] );
	$html = '';

	$master = array(
		'visits' => $masterViews,
		'conversions' => ( isset( $sptData[ $sptData[ 'master_id' ] . '_conversions' ] ) ? count( $sptData[ $sptData[ 'master_id' ] . '_conversions' ] ) : 0)
	);

	$variation = array(
		'visits' => $slaveViews,
		'conversions' => ( isset( $sptData[ $sptData[ 'slave_id' ] . '_conversions' ] ) ? count( $sptData[ $sptData[ 'slave_id' ] . '_conversions' ] ) : 0 )
	);

	if ($master['visits'] > 0) {
		$html .= '<strong>Master:</strong> ' . $masterViews . ' visits';
		$html .= ' / ' . $master['conversions'] . ' conversions';
		$html .= ' / ' . number_format( $sptMath->conversion_rate( $master ) * 100, 2 ) . '%';
		$html .= '<br />';
	} else {
		$html .= '<strong>Master:</strong> No stats yet!<br />';
	}

	if ($variation['visits'] > 0) {
		$html .= '<strong>Variation:</strong> ' . $slaveViews . ' visits';
		$html .= ' / ' . $variation['conversions'] . ' conversions';
		$html .= ' / ' . number_format( $sptMath->conversion_rate( $variation ) * 100, 2 ) . '%';
		$html .= '<br />';
	} else {
		$html .= '<strong>Variation:</strong> No stats yet!<br />';
	}

	return $html;
}

/*******************************************************************************
** sptAddJavascriptConversionFunction
** Add the javascript conversion tracking function to the header if required
** @since 1.2
*******************************************************************************/
function sptAddJavascriptConversionFunction() {
	if (is_admin())
		return;

	$splitTestCount = wp_count_posts('spt');

	if ($splitTestCount->publish > 0) {
		echo '<script type="text/javascript">function sptRecordConversion(id){jQuery.post("' . admin_url('admin-ajax.php') . '",{action: "sptAjaxRecordConversion",sptID: id});}</script>';
	}
}

/*******************************************************************************
** sptPremiumAdminHeader
** Include stuff in the admin dashboard header
** @since 1.2
*******************************************************************************/
function sptPremiumAdminHeader() {
	global $post;

	if ($post)
		$sptID = get_post_meta($post->ID, 'sptID', true);

	if (($post && $post->post_type == 'spt')  ||
		(!empty($sptID) && is_numeric($sptID) && $sptID != '0')) {

		wp_enqueue_script('sptPremiumHelper', plugins_url('simple-page-tester-premium/js/sptPremiumHelper.js'), true);
		wp_enqueue_style('sptShortcodeStyles', plugins_url('simple-page-tester-premium/css/sptShortcode.css'));
	}
}

/*******************************************************************************
** sptPremiumGlobalAdminNotices
** This should only be added to for really critical configuration problems that
** the admin should know about. In most cases this shows a notice to the admin
** explaining about the config problem and what they have to do to fix it.
** @since 1.2.2
*******************************************************************************/
function sptPremiumGlobalAdminNotices() {
	$plugin_file = 'simple-page-tester/simplepagetester.php';
	$sptOptions = get_option('sptOptions');
	$sptFreePluginActivationNotice = !(isset($sptOptions['sptFreePluginActivationNotice']) && $sptOptions['sptFreePluginActivationNotice'] == false);

	// Check to see if free Simple Page Tester plugin is enabled, if not show error
	if ($sptFreePluginActivationNotice && !is_plugin_active($plugin_file)) {
		$sptFile = trailingslashit(WP_PLUGIN_DIR) . plugin_basename('simple-page-tester/simplepagetester.php');

		$sptInstallText = '<a href="' . wp_nonce_url('update.php?action=install-plugin&plugin=simple-page-tester', 'install-plugin_simple-page-tester') . '">Click here to install from WordPress.org repo &rarr;</a>';
		if (file_exists($sptFile))
			$sptInstallText = '<a href="' . wp_nonce_url('plugins.php?action=activate&amp;plugin=' . $plugin_file . '&amp;plugin_status=all&amp;s', 'activate-plugin_' . $plugin_file) . '" title="' . esc_attr__('Activate this plugin') . '" class="edit">Click here to activate &rarr;</a>';

		echo '<div id="sptFreePluginActivationNotice" class="error">
			<p>Please ensure you have the <a href="http://wordpress.org/plugins/simple-page-tester/" target="_blank">Simple Page Tester</a> plugin installed and activated along with the Premium extension. ' . $sptInstallText . '<a href="#" style="float: right;" id="sptDismissFreePluginActivationNotice">Dismiss</a></p>
		</div>';
	}

	echo '<script type="text/javascript">
	jQuery("#sptDismissFreePluginActivationNotice").click(function() {
		e.preventDefault();
		var noticeId = jQuery(this).parent().parent().attr("id");

		jQuery.post(
			ajaxurl,
			{
				action: "sptDismissAdminNotice",
				notice_id: noticeId
			},
			function(result) {
				jQuery("#sptFreePluginActivationNotice").fadeOut(400);
			}
		);
	});
	</script>';
}

/*******************************************************************************
** sptAddWooCommerceConversionOption
** Add WooCommerce Conversion Tracking option to test edit screen
** @since 1.4
*******************************************************************************/
function sptAddWooCommerceConversionOption() {
	global $post;

	$sptData = unserialize(get_post_meta($post->ID, 'sptData', true));

	if (isset($sptData['woocommerce_conversion_tracking']) && $sptData['woocommerce_conversion_tracking'] == 'on') $sptData['woocommerce_conversion_tracking'] = ' checked="checked"';

	// Core options
	echo '<p><input type="checkbox" name="sptData[woocommerce_conversion_tracking]" id="sptWooCommerceConversionTracking"' .  (isset($sptData['woocommerce_conversion_tracking']) ? $sptData['woocommerce_conversion_tracking'] : '') . ' /> <label for="sptWooCommerceConversionTracking">Enable Automatic WooCommerce Conversion Tracking <sup><a href="https://simplepagetester.com/knowledge-base/how-woocommerce-automatic-ab-split-test-conversion-tracking-works/" target="_blank">?</a></sup></label></p>';

}

/*******************************************************************************
** sptTrackWooCommerceConversion
** Automatically track conversion to your tests when a WooCommerce order is made
** @since 1.4
*******************************************************************************/
function sptTrackWooCommerceConversion($order_id) {
	$splitTests = get_posts(array(
		'post_type' => 'spt',
		'posts_per_page' => -1
	));

	foreach ($splitTests as $splitTest) {
		$sptData = unserialize(get_post_meta($splitTest->ID, 'sptData', true));

		if (isset($sptData['woocommerce_conversion_tracking']) &&
			$sptData['woocommerce_conversion_tracking'] == 'on') {
			sptRecordConversion(array('id' => $splitTest->ID));
		}
	}
}

/*******************************************************************************
** sptPremiumAdminInit
** Initialise admin in the premium version
** @since 1.2
*******************************************************************************/
function sptPremiumAdminInit() {
	// Add necessary javascript for the admin page
	add_action('admin_head', 'sptPremiumAdminHeader');
}

/*******************************************************************************
** sptPremiumInit
** Initialise the premium version
** @since 1.0
*******************************************************************************/
function sptPremiumInit() {
	// Add meta boxes to edit screen
	add_action('add_meta_boxes', 'sptRegisterPremiumMetaBoxes', 99);

	// Register conversion shortcode
	add_shortcode('spt_conversion', 'sptRecordConversion');

	// Record the page ID in the session after redirect
	add_action('spt_after_redirect', 'sptRecordPageAfterRedirect', 10, 1);

	// 1.2.1: Add action to record last viewed test even when we don't redirect
	add_action('spt_after_force_same_no_redirect', 'sptRecordLastTestViewed');

	// Hook into variation tables to present conversion data
	add_action('spt_master_table_content_end', 'sptAddConversionsTotal', 10, 2);
	add_action('spt_variation_table_content_end', 'sptAddConversionsTotal', 10, 2);

	// Hook into chart to add conversion data
	add_filter('spt_chart_data', 'sptAddConversionsToChart', 10, 3);

	// Add filter to after data save to ensure conversions are kept after saving data
	add_filter('spt_after_data_save', 'sptSaveConversionsDuringSave', 10, 2);

	// Add hook to add premium options to individual tests
	add_action('spt_after_side_options', 'sptAddPremiumOptions', 10);

	// Add all the enabled post types buttons to the add new page test page
	add_action('spt_after_new_page_test_description', 'sptAddPostTypeButtonsToNewPageTestPage', 10);

	// Add filter to reset conversion stats
	add_filter('spt_after_stats_reset', 'sptResetConversionStats', 10, 1);

	// Add conversion stats to list screen
	add_filter('spt_list_column_test_stats', 'sptAddConversionStatsToList', 10, 3);

	// Add javascript conversion tracking function to header if required
	add_action('wp_head', 'sptAddJavascriptConversionFunction');

	// Add ajax handler for recording a conversion
	add_action('wp_ajax_sptAjaxRecordConversion', 'sptAjaxRecordConversion');
	add_action('wp_ajax_nopriv_sptAjaxRecordConversion', 'sptAjaxRecordConversion');

	// 1.4: Automatically track WooCommerce transactions
	add_action('spt_after_side_options', 'sptAddWooCommerceConversionOption', 5);
	add_action('woocommerce_thankyou', 'sptTrackWooCommerceConversion', 10, 1);
}

add_action('init', 'sptPremiumInit');
add_action('admin_init', 'sptPremiumAdminInit');

if (is_admin()) {
	add_action('admin_init', 'sptRegisterPremiumSettings');
	add_action('admin_menu', 'sptSetupPremiumSettingsPage', 30);
	add_action('admin_init', 'sptRegisterLicenseSettings');
	add_action('admin_menu', 'sptSetupLicenseDetailsPage', 40);
	add_action('admin_notices', 'sptPremiumGlobalAdminNotices');
}

require_once('shortcode-split-test.php');

/* Get options */
$sptLicenseData = get_option('sptLicenseData');

/* Update checker */
require 'plugin-updates/spt-plugin-update-checker.php';
$sptPremiumUpdateChecker = new SptPluginUpdateChecker(
	'http://simplepagetester.com/wp-admin/admin-ajax.php?action=sumGetUpdateInfo&plugin=premium&licence=' . $sptLicenseData['key'] . '&email=' . $sptLicenseData['email'],
	__FILE__,
	'spt-premium',
	12,
	''
);
