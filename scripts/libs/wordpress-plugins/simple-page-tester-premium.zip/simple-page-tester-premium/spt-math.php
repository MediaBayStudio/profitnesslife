<?php 
class SPT_Math {
	
	/******************************************************************************************
	** conversion_rate
	** Calculates the conversion rate of a test
	** @param $test and array containing two named int values, visits and conversions
	** @return float the calulated conversion rate
	******************************************************************************************/
	public function conversion_rate($test) { 
	    return $test['conversions'] / $test['visits']; 
	}

	/******************************************************************************************
	** change_percent
	** Calculates how much better one test is performing than another.
	** @param $master an array containing two named int values, visits and conversions
	** @param $variation an array containing two named int values, visits and conversions
	** @return float the percentage of change between the two given tests
	******************************************************************************************/
	public function change_percent($master, $variation) {
		return ($this->conversion_rate($variation) - $this->conversion_rate($master)) / $this->conversion_rate($master);
	}

	/******************************************************************************************
	** standard_error
	** Calculates the Standard Error of a test
	** @param $test a test
	** @return float the Standard Error of the test
	******************************************************************************************/
	public function standard_error($test) {
		$a = $this->conversion_rate($test) * (1 - $this->conversion_rate($test));

		return sqrt($a / $test['visits']);
	}

	/******************************************************************************************
	** zscore
	** Calculatest the Z-Score of two tests
	** @param $master an array containing two named in values, visits and conversions
	** @param $variation an array containing two named in values, visits and conversions
	** @return float the Z-Score
	******************************************************************************************/
	public function zscore($master, $variation) {
		$samplediff = $this->conversion_rate($variation) - $this->conversion_rate($master);

		$sd = sqrt( pow($this->standard_error($master), 2) + pow($this->standard_error($variation), 2) );

		return $samplediff / $sd;
	}

	/******************************************************************************************
	** cumulative_normal_distribution
	** Calculates the Cumulative Normal Distribution.
	** Adapted from http://www.abtester.com/calculator/. We adapted this code because
	** PHP's statistics math functions are lacking unless you install some whacky stats
	** package.
	** @param $zscore a Z-Score
	** @return float the Cumulative Normal Distribution
	******************************************************************************************/
	public function cumulative_normal_distribution($zscore) {
		$b1 =  0.319381530;
		$b2 = -0.356563782;
		$b3 =  1.781477937;
		$b4 = -1.821255978;
		$b5 =  1.330274429;
		$p  =  0.2316419;
		$c  =  0.39894228;

		if($zscore >= 0.0) {
			$t = 1.0 / ( 1.0 + $p * $zscore );
			return (1.0 - $c * exp( -$zscore * $zscore / 2.0 ) * $t *
			( $t * ( $t * ( $t * ( $t * $b5 + $b4 ) + $b3 ) + $b2 ) + $b1 ));
		} else {
			$t = 1.0 / ( 1.0 - $p * $zscore );
			return ( $c * exp( -$zscore * $zscore / 2.0 ) * $t *
			( $t * ( $t * ( $t * ( $t * $b5 + $b4 ) + $b3 ) + $b2 ) + $b1 ));
		}
	}
}
?>