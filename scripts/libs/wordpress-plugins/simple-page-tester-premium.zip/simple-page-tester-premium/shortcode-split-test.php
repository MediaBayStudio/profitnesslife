<?php

/*******************************************************************************
** sptSetupAddShortcodeTestPage
** Add SPT premium settings page to settings menu
** @since 1.2
*******************************************************************************/
function sptSetupPremiumAddNewMenuItems() {
	add_submenu_page(
		'edit.php?post_type=spt',
		'Add Shortcode Test',
		'Add Shortcode Test',
		'manage_options',
		'sptNewShortcodeSplitTest',
		'sptNewShortcodeSplitTest'
	);
}

/*******************************************************************************
** sptNewShortcodeTest
** Add new standard test screen
** @since 1.2
*******************************************************************************/
function sptNewShortcodeSplitTest() {
	echo '<div class="wrap">';

	echo '<h2>Shortcode Split Test Setup</h2>';

	echo '<h4>How shortcode split testing works:</h4>';

	echo '<p>A shortcode split test uses shortcodes to identify Master and Variation content
	within the page\'s content.</p>';

	echo '<p>For Example:<br />
	[spt_split_test id="123" variation="master"]This is the master content[/spt_split_test]<br />
	[spt_split_test id="123" variation="variation"]This is the variation content[/spt_split_test]</p>';

	echo '<p>Simple Page Tester recognises these shortcodes, identifies the test by the ID
	number and determines which variation to display.</p>';

	echo '<p>Shortcode split tests are great for testing element level changes instead of having to test a whole page. They can also be used in non-content areas such as shortcode enabled widgets, headers and more.';

	echo '<h4>Setup new shortcode split test:</h4>';

	echo '<div class="sptShortcodeContainer" style="padding: 0 1em 1.5em 1em;">';

	echo '<p><label for="sptTestName">Enter a name for your test:</label><br />
	<input type="text" name="sptTestName" id="sptTestName" value="" /><br />
	<em>This is a convenience name so you can recall your what your split test is about later.</em></p>


	<input type="button" class="button-primary" id="sptCreateShortcodeTest" value="Create New Shortcode Test" />
	<img id="sptNewShortcodeTestLoader" style="display: none;" src="' . plugins_url('simple-page-tester/images/spt-loader.gif') . '" />';

	echo '</div><!-- .sptNewShortcodeContainer -->
	</div><!-- .wrap -->';
}

/*******************************************************************************
** sptShortcodeDetailsMeta
** Display the Shortcode test type details meta box content
** @since 1.2
*******************************************************************************/
function sptShortcodeDetailsMeta() {
	global $post;

	$sptData = unserialize(get_post_meta($post->ID, 'sptData', true));

	if (!isset($sptData['splitTestType']) || $sptData['splitTestType'] != 'shortcode') {
		return;
	}

	// Retrieve stats data for test
	$statsData = sptGetStatsData( $post->ID );
	$masterViews = count( $statsData[ $sptData[ 'master_id' ] ][ 'views' ] );
	$slaveViews = count( $statsData[ $sptData[ 'slave_id' ] ][ 'views' ] );

	echo '<div class="sptShortcodeContainer">';
	echo '<div id="sptShortcodeChart" style="height: 350px;"></div>';

	// Sort out the Google Chart data

	echo '<script type="text/javascript" src="https://www.google.com/jsapi"></script>
	<script type="text/javascript">
	google.load("visualization", "1", {packages:["corechart"]});
	// Global container for the returned JSON data for the charts so we don\'t have to
	// query the DB again
	var shortcodeChartJSON = [];

	jQuery(document).ready(function() {
		sptLoadChart();

		// Take care of resizing the chart when the window is resized dynamically
		jQuery(window).resize(function() {
			jQuery("#sptShortcodeChart").html("");
			sptDrawChart(shortcodeChartJSON, "sptShortcodeChart");
		});
	});

	function sptLoadChart() {
		jQuery("#sptShortcodeChart").html("<img id=\"sptShortcodeChartLoader\" src=\"' . plugins_url('simple-page-tester/images/spt-loader.gif') . '\" />");
		jQuery.post(
			ajaxurl,
			{
				action: "sptAjaxGetChartData",
				splitTestID: ' . $post->ID . '
			},
			function(results) {
				console.log("Unfiltered results: " + results);
				var jsonResults = jQuery.parseJSON(results);
				console.log(jsonResults);
				if (jsonResults == null)
					jsonResults = Array();

				// Set global JSON storage
				shortcodeChartJSON = jsonResults;

				sptDrawChart(shortcodeChartJSON, "sptShortcodeChart");
				jQuery("#sptShortcodeChartLoader").hide();
			}
		);
	}
	</script>';

	echo '</div>';

	echo '<div class="sptShortcodeContainer">
		<table id="sptMaster" width="100%">
			<tr>
				<th colspan="3">
					<h3>Master</h3>
					<input name="sptData[master_id]" id="sptMasterID" type="hidden" value="1" />
				</th>
			</tr>

			<tr>
				<th scope="row" colspan="1">Master Shortcode:</th>
				<td colspan="2">
					<input style="background: #EEE; width: 100%;" name="" id="sptMasterShortcodeText" type="text" value="[spt_split_test id=' . $post->ID . ' variation=&quot;master&quot;]Your master content goes here[/spt_split_test]" readonly="readonly" />
				</td>
			</tr>
			<tr>
				<th scope="row" colspan="1">Adjust Percentage Of Views:</th>
				<td colspan="2">
					<select name="sptData[master_weight]" id="master_weight">';

	for ($i = 90; $i > 0; $i = $i - 10) {
		echo '<option value="' . $i . '"' .
		($sptData['master_weight'] == $i ? ' selected="selected"' : '') .
		'>' . $i . '</option>';
	}
	echo '			</select> %
				</td>
			</tr>
			<tr>
				<th scope="row" colspan="1">Total Unique Visits:</th>
				<td colspan="2">' . $masterViews . '</td>
			</tr>';

	do_action('spt_master_table_content_end', $post->ID, $sptData['master_id']);

	echo '</table>
	</div>';

	echo '<div class="sptShortcodeContainer">
		<table id="sptMaster" width="100%">
			<tr>
				<th colspan="3">
					<h3>Variation</h3>
					<input name="sptData[slave_id]" id="sptVariationID" type="hidden" value="2" />
				</th>
			</tr>

			<tr>
				<th scope="row" colspan="1">Variation Shortcode:</th>
				<td colspan="2">
					<input style="background: #EEE; width: 100%;" name="" id="sptVariationShortcodeText" type="text" value="[spt_split_test id=' . $post->ID . ' variation=&quot;variation&quot;]Your variation content goes here[/spt_split_test]" readonly="readonly" />
				</td>
			</tr>
			<tr>
				<th scope="row" colspan="1">Adjust Percentage Of Views:</th>
				<td colspan="2">
					<select name="sptData[slave_weight]" id="slave_weight">';

	for ($i = 90; $i > 0; $i = $i - 10) {
		echo '<option value="' . $i . '"' .
		($sptData['slave_weight'] == $i ? ' selected="selected"' : '') .
		'>' . $i . '</option>';
	}
	echo '			</select> %
				</td>
			</tr>
			<tr>
				<th scope="row" colspan="1">Total Unique Visits:</th>
				<td colspan="2">' . $slaveViews . '</td>
			</tr>';

	do_action('spt_variation_table_content_end', $post->ID, $sptData['slave_id']);

	echo '</table>
	</div>';

	// TODO:
	// Print graph
	// Test with a new test

	echo '<script type="text/javascript">
	jQuery("#sptMasterShortcodeText, #sptVariationShortcodeText").click(function() {
		jQuery(this).select();

		jQuery(this).mouseup(function() {
	        // Prevent further mouseup intervention
	        jQuery(this).unbind("mouseup");
	        return false;
	    });
	});
	</script>';
}

/*******************************************************************************
** sptCreateShortcodeTest
** Ajax handler for creating a shortcode test
** @since 1.2
*******************************************************************************/
function sptCreateShortcodeTest() {
	$testName = sptFilterData($_POST['testName']);

	if (empty($testName)) {
		echo '-1';
		die();
	}

	global $wpdb;

	$new_post_author = wp_get_current_user();

	$new_post = array(
		'post_author' => $new_post_author->ID,
		'post_date' => current_time('mysql'),
		'post_date_gmt' => current_time('mysql', true),
		'post_status' => 'publish',
		'post_title' => $testName,
		'post_type' => 'spt',
	);

	$new_post_id = wp_insert_post($new_post, false);

	// Check if successfully created
	if ($new_post_id != 0) {
		// Add master and slave IDs

		$sptData = array(
			'splitTestType' => 'shortcode',
			'master_id' => 1,
			'master_weight' => 50,
			'master_visits' => array(),
			'slave_id' => 2,
			'slave_weight' => 50,
			'slave_visits' => array(),
			'winner_action' => 'archive'
		);

		update_post_meta($new_post_id, 'sptData', serialize($sptData));

		// Create archiver cron job for this split test
		wp_schedule_event( current_time( 'timestamp', true ), 'daily', 'spt_archive_stats', array( $new_post_id ) );


	}

	echo $new_post_id;

	die();
}

/*******************************************************************************
** sptShortcodeSplitTest
** Handler for shortcode split tests
** @since 1.2
*******************************************************************************/
function sptShortcodeSplitTest($atts, $content) {
	global $sptSession;

	extract($atts);

	// Get the SPT ID from the shortcode, bail if not found
	if (!isset($id) || empty($id))
		return;

	// Get the variation type from the shortcode, bail if not found
	if (!isset($variation) || empty($variation))
		return;

	// Check the variation type for validity
	if ($variation != 'master' && $variation != 'variation')
		return;

	// Retrieve the split test data and exit if it's not a valid test
	$sptData = unserialize(get_post_meta($id, 'sptData', true));
	if ($sptData == null || empty($sptData))
		return;

	$showVariation = $variation;
	$sessionForceSame = $sptSession->getData('spt_force_same_' . $id);
	if (isset($sptData['force_same']) && $sptData['force_same'] == 'on' &&
		isset($sessionForceSame) && !empty($sessionForceSame)) {
		// We're forcing the same variation for this test so tell it to show the same one
		$showVariation = $sessionForceSame;
	} else {
		/* Either we are not forcing the same and we should show variation depending on distribution
		OR we are forcing the same and this is the first time we've seen this test so we need to
		show variation based on distribution then set the force same session variable for next time */
		$variationToShow = $sptSession->getData('spt_shortcode_variation_to_show');
		if (!isset($variationToShow[$id])) {
			// Determine which variation to show
			list($usec, $sec) = explode(' ', microtime());
			mt_srand((float)$sec + ((float)$usec * 100000));
			$randNum = mt_rand(1, 100);

			if ($randNum <= $sptData['master_weight'])
				$showVariation = 'master';
			else
				$showVariation = 'variation';

			$variationToShow[$id] = $showVariation;
			$sptSession->setData('spt_shortcode_variation_to_show', $variationToShow);
		} else {
			$showVariation = $variationToShow[$id];
		}
	}

	// Show the variation
	if ($showVariation == $variation) {
		// Set the last variation seen for this test
		$sptSession->setData('spt_' . $id . '_last_pageid', $showVariation);

		// Record the visit
		sptShortcodeRecordVisit($id, $sptData, $showVariation);

		// Record the last viewed test
		sptRecordLastTestViewed($id);

		// Return with the content
		return do_shortcode($content);
	}
}

/*******************************************************************************
** sptShortcodeRecordVisit
** Record the visit to the shortcode variation
** @param $sptID - the ID of the split test
** @param $sptData - the data of the split test
** @param $variation - the variation to record against
** @since 1.2
*******************************************************************************/
function sptShortcodeRecordVisit($sptID, $sptData, $variation) {
	global $sptSession;

	// If in doubt, record the visit, next we'll test some conditions where it shouldn't recorded
	$recordTheVisit = true;

	// TODO: Detect if logged in users should be tracked or not
	/*if (global option says not to record logged in users and user is logged in) {
		$recordTheVisit = false;
	}*/

	// Check if we should record the visit if we're forcing visitors to view the same page
	$sessionForceSame = $sptSession->getData('spt_force_same_' . $sptID);
	if (isset($sptData['force_same']) && $sptData['force_same'] == 'on' &&
		isset($sessionForceSame) && !empty($sessionForceSame)) {
		$recordTheVisit = false;
	}

	// Record the visit, but only if all preconditions are satisfied
	if ($recordTheVisit) {

		if ($variation == 'master') $masterOrSlave = $sptData['master_id'] . '_visits';
		if ($variation == 'variation') $masterOrSlave = $sptData['slave_id'] . '_visits';

		$sptData[$masterOrSlave][] = array(
			'timestamp' => current_time('timestamp'),
			'ip' => getenv(REMOTE_ADDR)
		);

		// If we are forcing users to view the same page, record the page so we know
		// not to record future visits
		if (isset($sptData['force_same']) && $sptData['force_same'] == 'on') {
			// Set the force same session variable to this variation
			$sptSession->setData('spt_force_same_' . $sptID, $variation);
		}

		update_post_meta($sptID, 'sptData', serialize($sptData));
	}
}

/*******************************************************************************
** sptRemoveVariationToShow
** Remove the variation to show from session memory
** @since 1.2
*******************************************************************************/
function sptRemoveVariationToShow() {
	global $sptSession;
	$sptSession->setData('spt_shortcode_variation_to_show', array());
}

/*******************************************************************************
** sptPremiumAdminShortcodeHeader
** Include stuff in the admin dashboard header for the new shortcode page
** @since 1.2
*******************************************************************************/
function sptPremiumAdminShortcodeHeader() {
	global $current_screen;

	if ($current_screen &&
		$current_screen->post_type == 'spt' &&
		$current_screen->id == 'spt_page_sptNewShortcodeSplitTest') {

		wp_enqueue_script('sptNewShortcodeHelper', plugins_url('simple-page-tester-premium/js/sptNewShortcodeHelper.js'), true);
		wp_enqueue_style('sptShortcodeStyles', plugins_url('simple-page-tester-premium/css/sptShortcode.css'));

		echo '<script type="text/javascript">
		var sptAdminUrl = \'' . admin_url() . '\';
		</script>';

		return;
	}

	global $post;

	if ($post)
		$sptID = get_post_meta($post->ID, 'sptID', true);

	if (($post && $post->post_type == 'spt')  ||
		(!empty($sptID) && is_numeric($sptID) && $sptID != '0')) {

		wp_enqueue_script('sptShortcodeHelper', plugins_url('simple-page-tester-premium/js/sptShortcodeHelper.js'), true);
	}
}

/*******************************************************************************
** sptPremiumShortcodeInit
** Do init tasks for shortcode test types
** @since 1.2
*******************************************************************************/
function sptPremiumShortcodeInit() {
	// Display shortcode test type details on the split test edit screen
	add_action('spt_alternate_split_test_type_details', 'sptShortcodeDetailsMeta');

	// Register split test shortcode
	add_shortcode('spt_split_test', 'sptShortcodeSplitTest');

	// Register ajax function/s
	add_action('wp_ajax_sptCreateShortcodeTest', 'sptCreateShortcodeTest');

	// Remove variation to show from session
	add_action('template_redirect', 'sptRemoveVariationToShow');
}

/*******************************************************************************
** sptPremiumShortcodeAdminInit
** Initialise admin for the shortcode test type
** @since 1.2
*******************************************************************************/
function sptPremiumShortcodeAdminInit() {
	// Add necessary javascript for the admin page
	add_action('admin_head', 'sptPremiumAdminShortcodeHeader');
}

add_action('init', 'sptPremiumShortcodeInit');
add_action('admin_init', 'sptPremiumShortcodeAdminInit');

if (is_admin()) {
	add_action('admin_menu', 'sptSetupPremiumAddNewMenuItems', 20);
}

?>
