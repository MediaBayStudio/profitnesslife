jQuery(document).ready(function(){
	jQuery('#sptCreateShortcodeTest').click(function() {
		jQuery(this).addClass('button-disabled');

		var sptTestName = jQuery('#sptTestName').val();

		if (typeof sptTestName === 'undefined' || sptTestName.length <= 0) {
			alert('Please enter a name for your split test!');
			jQuery(this).removeClass('button-disabled');
			return;
		}

		jQuery('#sptNewShortcodeTestLoader').show();

		jQuery.post(
			ajaxurl,
			{
				action: 'sptCreateShortcodeTest',
				testName: sptTestName
			},
			function(newTestID) {
				jQuery('#sptNewShortcodeTestLoader').hide();
				if (parseInt(newTestID) != -1)
					self.parent.location.href = sptAdminUrl + 'post.php?post=' + newTestID + '&action=edit';
				else
					alert('There was an internal error when creating your test. Please try again.');
			}
		);
	});
});