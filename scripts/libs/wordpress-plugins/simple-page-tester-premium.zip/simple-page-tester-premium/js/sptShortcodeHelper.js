jQuery(document).ready(function(){
	// TODO:
	// Draw graph
	// sptDrawChart(spt_shortcode_row_data, 'sptShortcodeGraph');
});