<?php
$measure_timeline_count = $user_data['measure_timeline'] ? count( $user_data['measure_timeline'] ) : 0 ?>
<section class="measure-sect">
  <h2 class="measure-sect__title">Замеры обьёмов тела</h2>
  <p class="measure-sect__descr">Не забывай еженедельно измерять свои параметры</p>
  <div class="measure-sect__user-data"> <?php
    if ( $measure_timeline_count === 0 ) {
      if ( $user_data['initial_measure_chest'] && $user_data['initial_measure_waist'] && $user_data['initial_measure_hip'] ) {
        $chest = $user_data['initial_measure_chest'];
        $waist = $user_data['initial_measure_waist'];
        $hip = $user_data['initial_measure_hip'];
        $measure_date = $user_data['initial_measure_date'];
      } else {
        $chest = 0;
        $waist = 0;
        $hip = 0;
        $measure_date = '';
      }
    } else {
      $chest = $user_data['measure_timeline'][ $current_week_number - 1 ]['chest'];
      $waist = $user_data['measure_timeline'][ $current_week_number - 1 ]['waist'];
      $hip = $user_data['measure_timeline'][ $current_week_number - 1 ]['hip'];
      $measure_date = $user_data['measure_timeline'][ $current_week_number - 1 ]['date'];
    } ?>
    <div class="measure-sect__user-current-data measure-current">
      <span class="measure-current__title">Текущие параметры</span>
      <span class="measure-current__date"><?php echo $measure_date ?></span>
      <table class="measure-current__table">
        <tr>
          <td>грудь (см)</td>
          <td><?php echo $chest ?></td>
        </tr>
        <tr>
          <td>талия (см)</td>
          <td><?php echo $waist ?></td>
        </tr>
        <tr>
          <td>бёдра (см)</td>
          <td><?php echo $hip ?></td>
        </tr>
      </table>
    </div> <?php
    if ( $measure_timeline_count === 0 ) : ?>
      <form action="#" method="POST" class="measure-sect__form measure-form"> <?php
        // $current_week_number объявлена в functions.php
        // за 2-3 дня до конца недели нужно включать доступность полей
        switch ( $current_week_number ) {
          case 2:
            $week_text = 'второй';
            break;
          case 3:
            $week_text = 'третьей';
            break;
          default:
            $week_text = 'первой';
            break;
        } ?>
        <span class="measure-form__title">Мои параметры в конце <?php echo $week_text ?> недели</span>
        <div class="measure-form__data"> <?php
          $img_prefix = $user_data['sex'] === 'Мужской' ? 'male' : 'female' ?>
          <img src="<?php echo $template_directory_uri ?>/img/icon-measure-<?php echo $img_prefix ?>.svg" alt="Изображение мест обхватов" class="measure-form__img">
          <table class="measure-form__data-table">
            <tr>
              <td>
                <input type="number" name="chest" placeholder="Обхват груди">
              </td>
              <td>см</td>
            </tr>
            <tr>
              <td>
                <input type="number" name="waist" placeholder="Обхват талии">
              </td>
              <td>см</td>
            </tr>
            <tr>
              <td>
                <input type="number" name="hip" placeholder="Обхват бёдер">
              </td>
              <td>см</td>
            </tr>
          </table>
          <button class="measure-form__btn btn btn-green">Сохранить</button>
        </div>
      </form> <?php
    endif ?>
  </div>
</section>
