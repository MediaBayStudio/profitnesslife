;
(function() {

  let weightForm = document.querySelector('.weight-form'),
    updateWeightChart = function(chart, label, data) {
      chart.data.labels.push(label);
      chart.data.datasets.forEach(dataset => dataset.data.push(data));
      chart.options.scales.y.min = data - 2;
      chart.update();
    };

  weightForm['current-weight'].addEventListener('input', function(e) {
    weightForm.submit.classList.toggle('disabled', e.target.value.length <= 1);
  });

  weightForm.addEventListener('submit', function(e) {
    e.preventDefault();
    let data = new FormData(weightForm),
      date = new Date(),
      weight = weightForm['current-weight'].value,
      today = ('0' + date.getDate()).slice() + '.' + (date.getMonth() + 1) + '.' + date.getFullYear();

    data.append('action', 'weight_send');
    data.append('date', today);

    weightForm.classList.add('loading');
    weightForm.submit.blur();

    fetch(weightForm.action, {
        method: 'POST',
        body: data
      })
      .then(function(response) {
        if (response.ok) {
          return response.text();
        } else {
          console.log('Ошибка ' + response.status + ' (' + response.statusText + ')');
          return '';
        }
      })
      .then(function(response) {
        weightForm.classList.remove('loading');
        weightForm.classList.add('disabled');




        id('current-weight-date').textContent = today;
        id('current-weight-number').textContent = weight + ' кг';
        id('weight-goal-current').textContent = Math.abs(weight - weightForm.getAttribute('data-target-weight'));

        if (weightChart) {
          updateWeightChart(weightChart, today.slice(0, -5), weight);
        }

      })
      .catch(function(err) {
        console.log(err);
      });
  });
})();