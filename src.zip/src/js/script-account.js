document.addEventListener('DOMContentLoaded', function() {

//=include ../sections/header/header.js

//=include ../sections/mobile-menu/mobile-menu.js

//=include ../sections/account-hero/account-hero.js

//=include ../sections/account-weight-chart/account-weight-chart.js

//=include ../sections/account-measure-chart/account-measure-chart.js

//=include ../sections/footer/footer.js

});