document.addEventListener('DOMContentLoaded', function() {

//=include ../sections/header/header.js

//=include ../sections/mobile-menu/mobile-menu.js

//=include ../sections/questionnaire-complete/questionnaire-complete.js

//=include ../sections/questionnaire-incomplete/questionnaire-incomplete.js

//=include ../sections/footer/footer.js

});