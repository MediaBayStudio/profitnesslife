document.addEventListener('DOMContentLoaded', function() {

//=include ../sections/header/header.js

//=include ../sections/mobile-menu/mobile-menu.js

//=include ../sections/index-hero/index-hero.js

//=include ../sections/index-features/index-features.js

//=include ../sections/index-interface/index-interface.js

//=include ../sections/index-invite/index-invite.js

//=include ../sections/index-reviews/index-reviews.js

//=include ../sections/index-team/index-team.js

//=include ../sections/index-form/index-form.js

//=include ../sections/index-payment/index-payment.js

//=include ../sections/index-chat/index-chat.js

//=include ../sections/index-instagram/index-instagram.js

//=include ../sections/footer/footer.js

});